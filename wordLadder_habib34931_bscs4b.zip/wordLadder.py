import json
import Queue
from collections import deque

class WordLadder:


    def executioner(dictkeys):
        frontier=Queue.PriorityQueue()
        

    def makeChain(self,fword,tword,keylist):
        frontier=deque([])
        explored=[]
        words=[]
        frontier.append((fword,[fword],0))
        while frontier:
            word, words, chainLen=frontier.popleft()
            print(frontier)
            if str(word).lower()==tword:
                self.displayChain(words)
                return []

            if not word in explored:
                explored.append(word)
                chainLen=chainLen+1
                for i in keylist:
                    if self.adjacent(word, i):
                        dictstr=str(i).lower()
                        frontier.append((dictstr,words+[dictstr],chainLen))

        return []

    def adjacent(self,w1,w2):
        
        count = 0
        i=0
        w3=str(w2).lower()
        n = len(w1)
        n1=len(w2)
        if n!=n1:
            return False
        for x in range (i,len(w1)):
            if w1[x] != w3[x]:
                count=count+1
            if count > 1:
                return False;
        if count==1:
            return True;
        if count!=1:
            return False;

    def displayChain(self,chain):
        print(chain)

if __name__=="__main__":
    wl=WordLadder()
    with open('E:\Study\semester5\AdvanceProg\Assignment\dictionary.json') as json_data:
        test = json_data.read()
        d = json.loads(test)
    firstWord = raw_input("Please Enter Starting Word")
    secondWord=raw_input("Please Enter Target Word")
    if firstWord!="" and secondWord!="" and len(firstWord)==len(secondWord):
        wl.makeChain(firstWord,secondWord,d.keys())
    #print(d.keys())
